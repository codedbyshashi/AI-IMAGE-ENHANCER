# Dummy arrays are not implemented in the simulator. This file allows the dummy
# array tests to be imported, but they are skipped on the simulator.

Array = None
