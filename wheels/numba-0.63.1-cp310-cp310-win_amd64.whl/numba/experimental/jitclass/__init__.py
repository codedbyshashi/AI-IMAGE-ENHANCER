from numba.experimental.jitclass.decorators import jitclass
from numba.experimental.jitclass import boxing  # Has import-time side effect
from numba.experimental.jitclass import overloads  # Has import-time side effect
